
%Write a MATLAB/Python program to read an image and perform Lapliciant filter mask.
clc;
clear all;
close all;

image = imread('pexels-photo-1661179.jpeg');         % Read source Image
if size(image, 3) == 3
    grayImage = rgb2gray(image);                     % Convert the image to grayscale
else
    grayImage = image;
end
laplacianMask = [0, 1, 0;                            % Laplacian filter mask (kernel)
                1, -4, 1;
                0, 1, 0];
filteredImage = conv2(double(grayImage), laplacianMask, 'same'); % convolution using the Laplacian filter mask

subplot(1, 2, 1);
imshow(grayImage);                                  % Display the original 
title('Original Image');

subplot(1, 2, 2);
imshow(uint8(filteredImage));                       % Display filtered images
title('Laplacian Filtered Image');
colormap gray;                                      % To a grayscale colormap
