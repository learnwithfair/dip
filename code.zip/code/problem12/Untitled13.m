
%13. Write a MATLAB/Python program and plot multilevel speech resolution.
clc;
clear all;
close all;
[speechSignal, Fs] = audioread('intro.mp3');         % Read the speech signal

% Parameters for CWT
scales = 1:64;                                       % Scale levels
waveletName = 'morl';                                % Wavelet function (change as needed)
cwtCoeffs = cwt(speechSignal, scales, waveletName);  % Perform CWT
disp(cwtCoeffs);
% Create a time-frequency plot
time = (0:length(speechSignal)-1) / Fs;
freq = scal2frq(scales, waveletName, 1/Fs);

figure;
imagesc(time, freq, abs(cwtCoeffs));
colormap(jet);
colorbar;
set(gca, 'YDir', 'normal');
xlabel('Time (s)');
ylabel('Frequency (Hz)');
title('Continuous Wavelet Transform - Multilevel Speech Resolution');
