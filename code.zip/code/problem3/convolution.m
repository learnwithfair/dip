% Write A MATLAB/Python Program To Read An Image And Perform Convolution With 3×3 Mask.
clc;
close all;
clear all;
image = imread('Untitled2.jpeg');        % Read source Image
image = double(image);                   % Convert the image to double for convolution
mask = [1, 2, 1; 0, 0, 0; -1, -2, -1];   % Define the 3x3 mask (kernel)

% Separate the RGB channels
redChannel = image(:,:,1);               % To access the first color(Red) channel
greenChannel = image(:,:,2);             % To access the 2nd color(Green) channel
blueChannel = image(:,:,3);              % To access the 3rd color(Blue) channel

% Perform convolution on each channel
convolvedRed = conv2(redChannel, mask, 'same');
convolvedGreen = conv2(greenChannel, mask, 'same');
convolvedBlue = conv2(blueChannel, mask, 'same');

% Combine the convolved channels back into an RGB image
convolvedImage = cat(3, convolvedRed, convolvedGreen, convolvedBlue);

% Display the original 
subplot(1, 2, 1);
imshow(uint8(image));                   % Unsigned 8-bit integers, (0 to 255).
title('Original Image');

%Display convolved images
subplot(1, 2, 2);
imshow(uint8(convolvedImage));          % Display the convolved Image
title('Convolved Image');