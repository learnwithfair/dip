
% For the given image perform edge detection using different operators and compare the results.
clc;clear;close all;
image = imread('LINE3.JPG');            % Read source Image 
if size(image, 3) == 3                  % RGB image
    grayImage = rgb2gray(image);        % Convert to gray scale
else
    grayImage = image;
end

% Apply edge detection using different operators
sobelEdges = edge(grayImage, 'sobel');      % Sobel Operators
prewittEdges = edge(grayImage, 'prewitt');  % prewitt Operators
robertsEdges = edge(grayImage, 'roberts');  % roberts Operators
cannyEdges = edge(grayImage, 'canny');      % canny Operators

% Display the original image and the edge detection results side by side
subplot(3, 2, 1);
imshow(grayImage);                          % Display Original Image
title('Original Image');
subplot(3, 2, 2);
imshow(sobelEdges);                         % Display Sobel Edge Detection Image
title('Sobel Edge Detection');
subplot(3, 2, 3);
imshow(prewittEdges);                       % Display Prewitt Edge Detection Image
title('Prewitt Edge Detection');
subplot(3, 2, 4);
imshow(robertsEdges);                       % Display Roberts Edge Detection Image
title('Roberts Edge Detection');
subplot(3, 2, 5);
imshow(cannyEdges);                         % Display Canny Edge Detection Image
title('Canny Edge Detection');
colormap gray;                              % To a grayscale colormap
