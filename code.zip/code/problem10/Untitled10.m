%. Perform image enhancement, smoothing and sharpening, in spatial domain using 
%different spatial filters and compare the performances
clc;close all; clear;
inputImage = imread('Untitled2.jpeg');              % Read source Image 
grayImage = rgb2gray(inputImage);                   % Convert to gray scale
subplot(221);
imshow(grayImage);                                  % Display the original image
title('Original Image');

% ===========Image enhancement using histogram equalization=============
enhancedImage = histeq(grayImage);                  % To enhance the contrast of an image
subplot(222);
imshow(enhancedImage);                              % Display the Enhanced Image
title('Enhanced Image (Histogram Equalization)');

% ===================== Smoothing using Gaussian filter=======================
gaussianFilter = fspecial('gaussian', [5 5], 1);   % 5x5 Gaussian filter kernel with a standard deviation of 1
smoothedImage = imfilter(grayImage, gaussianFilter, 'replicate');  % To apply various filters to an image
subplot(223);
imshow(smoothedImage);                             % Display the Smoothed Image
title('Smoothed Image (Gaussian Filter)');

%  =====================Sharpening using Laplacian filter =====================
laplacianFilter = fspecial('laplacian', 0);       % laplacian filter kernel with a standard deviation of 0
sharpenedImage = imfilter(grayImage, laplacianFilter, 'replicate');  % To apply various filters to an image
subplot(224);
imshow(sharpenedImage);                            % Display the Sharpened Image
title('Sharpened Image (Laplacian Filter)');

% Sharpening using Unsharp Masking
% blurredImage = imfilter(grayImage, gaussianFilter, 'replicate');
% unsharpMask = grayImage - blurredImage;
% sharpenedImage2 = grayImage + unsharpMask;
% subplot(2, 3, 5);
% imshow(sharpenedImage2);
% title('Sharpened Image (Unsharp Masking)');

% Display comparisons
% subplot(2, 3, 6);
% imshow(grayImage);
% hold on;
% h = text(size(grayImage, 2) / 2, 10, 'Original Image', 'Color', 'w', 'HorizontalAlignment', 'center');
% set(h, 'FontSize', 10);
% h = text(size(grayImage, 2) / 2, size(grayImage, 1) - 10, 'Different Image Enhancements', 'Color', 'w', 'HorizontalAlignment', 'center');
% set(h, 'FontSize', 10);
% hold off;


set(gcf, 'Position', get(0, 'Screensize'));          % Adjust the figure layout