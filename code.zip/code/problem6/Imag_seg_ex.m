% Write a MATLAB/Python program to Character Segment of an image
clc;
clear;
close all;
imagen=imread('image_a.JPG');         % Read source Image 
figure(1)
imshow(imagen);                       % Show source image with noise
title('Input Image with Noise')
if size(imagen,3)==3                  % RGB image
    imagen=rgb2gray(imagen);          % Convert to gray scale
end
% Convert to binary image
threshold = graythresh(imagen);
imagen =~im2bw(imagen,threshold);
% Remove all object containing fewer than 30 pixels
imagen = bwareaopen(imagen,30);
pause(1)
figure(2)
imshow(~imagen);                      % Show image binary image without noise
title('Input Image without Noise');
[L Ne]=bwlabel(imagen);               % Label connected components
propied=regionprops(L,'BoundingBox'); % Measure properties of image regions
hold on                               % To overlay multiple plots on the same set of axes
% Plot Bounding Box
for n=1:size(propied,1)
    rectangle('Position',propied(n).BoundingBox,'EdgeColor','g','LineWidth',2)
end
hold off
pause (1)                             % To pause the program for 1 second.
% Objects extraction
figure(3)
for n=1:Ne
    [r,c] = find(L==n);
    n1=imagen(min(r):max(r),min(c):max(c));
    imshow(~n1);                      % show individual character of an image
    pause(1)                          % To pause the program for 1 second.
end