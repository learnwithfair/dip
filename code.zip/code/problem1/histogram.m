%**************************** Histogram ****************************
clc;
clear all;
close all;
%i1=input('image name with location:'); % Get Image from user
im=imread('fruit-2999796.jpg');         % Read source Image
gIm=rgb2gray(im);                       % Convert RGB to Gray scale image       
subplot(2,1,1);
figure(1)
imshow(gIm);                            % Display Gray scale image
title('Source image');

sz=size(gIm);                           % Image Dimension width by height     
n=sz(1)*sz(2);                          % Height * Width
for rk=0:2:255
    a=find(gIm==rk);                    % Check the condition
    sz=size(a);
    nk=sz(1);                           % Assign the Height of checked image
    pk(rk+1)=nk/n;                      % Calculate the Histogram value
end
subplot(2,1,2);
bar(pk);                                % Plot the Histogram
axis([0,256,0,0.01]);                   % Axis set-up 
title('Histogram');   

